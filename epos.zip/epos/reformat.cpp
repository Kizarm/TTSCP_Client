#include <stdio.h>
#include <string>
#include <cstring>
#include <sndfile.h>

struct wave_header {
	char string1[4];
	int  total_length;
	char string2[8];
	//int  fmt_length;
	//short int  datform, numchan, sf1, sf2, avr1, avr2, alignment, samplesize;
	//chaloupka
	int  fmt_length,sf1, avr1;
	short int datform, numchan,alignment, samplesize;
	char string3[4];
	int  buffer_idx;
};			// .wav file header

void print_header (const wave_header & wh) {
  return;
  printf("total %d bytes, form = %04X, ch=%d, sr=%d, hl=%d, ss=%d\n", wh.total_length, (unsigned) wh.datform,
         (int) wh.numchan, (int) wh.sf1, (int) wh.fmt_length, (int) wh.samplesize);
  const unsigned char * ptr = (const unsigned char*) &wh;
  for (unsigned n=0; n<sizeof(wave_header); n++) {
    printf("%02X", ptr[n]);
  }
  printf("\n");
}
bool mangle (std::string & out, const char * in) {
  const std::string wav(".wav"), ins (in);
  const size_t n = ins.rfind (wav);
  if (n == std::string::npos) {
    fprintf(stderr, "Input must be a *.wav file\n");
    return false;
  }
  out = ins.substr(0, n);
  out+= "_copy" + wav;
  return true;
}
enum PROCESS_ERR {
  OK,
  NO_INPUT, BAD_FORMAT, NO_OUTPUT
};
static PROCESS_ERR process (const char * in, const char * out) {
  PROCESS_ERR err = OK;
  printf("%s -> %s\n", in, out);
  FILE * inf = nullptr;
  SNDFILE * outf = nullptr;
  do {
    inf = fopen(in, "r");
    if (!inf) {
      fprintf(stderr, "no input file \"%s\"\n", in);
      err = NO_INPUT;
      break;
    }
    wave_header wh;
    const int n = fread (&wh, 1, sizeof(wave_header), inf);
    if (n != sizeof(wave_header)) {
      fprintf(stderr, "bad read header \"%s\"\n", in);
      err = BAD_FORMAT;
      break;
    }
    if (wh.samplesize != 16) {
      fprintf(stderr, "bad sample len \"%s\"\n", in);
      err = BAD_FORMAT;
      break;
    }
    print_header (wh);
    SF_INFO info;
    memset (&info, 0, sizeof(SF_INFO));
    info.channels = wh.numchan;
    info.format   = SF_FORMAT_WAV | SF_FORMAT_GSM610; // compress or SF_FORMAT_PCM_16;
    info.samplerate = wh.sf1;
    if (sf_format_check (&info) == SF_FALSE) {
      fprintf(stderr, "bad output format\n");
      err = BAD_FORMAT;
      break;
    }
    outf = sf_open (out, SFM_WRITE, &info);
    if (!outf) {
      fprintf(stderr, "cannot open output file \"%s\"\n", out);
      err = NO_OUTPUT;
      break;
    }
    const int buflen = 0x400;
    short buffer [buflen];
    int count = 0;
    for (;;) {
      int r = fread (buffer, sizeof(short), buflen, inf);
      count += r;
      for (int i=0; i<r; i++) buffer[i] *= 2; // zesílit
      sf_write_short (outf, buffer, r);
      if (r != buflen) break;
    }
    printf("readen %d samples\n", count * 2);
  } while (false);
  switch (err) {
    case OK: sf_close (outf);
    case NO_OUTPUT:
    case BAD_FORMAT: fclose(inf);
    case NO_INPUT:
    default: break;
  }
  return err;
}
/* Čarovat s headery epos se mi zdálo moc divné,
 * stejný formát používá client i server a sáhnout do
 * toho provede bůhví co. Zde je použita knihovna sndfile.
 * */
int main(int argc, char *argv[]) {
  if (argc != 2) {
    printf("usage:\n\t%s input.wav\n", argv[0]);
    return 0;
  }
  std::string outname;
  if (!mangle (outname, argv[1])) return -1;
  if (process(argv[1], outname.c_str()) != OK) return -1;
  printf("Result = OK\n");
  return 0;
}
